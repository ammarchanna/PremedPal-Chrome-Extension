chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "getTabDOM") {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs.length > 0) {
        var tabId = tabs[0].id; 
        //chrome.tabs.executeScript(tabId, { code: "document.documentElement.outerHTML" }, function(result) {
        chrome.tabs.executeScript(tabId, { code: "document.body.outerHTML" }, function(result) {
          if (chrome.runtime.lastError) {
            sendResponse({ error: chrome.runtime.lastError.message });
          } else {
            var dom = result[0];
            sendResponse({ dom: dom }); 
          }
        });
      } else {
        sendResponse({ error: "Tab not found" });
      }
    });

    return true;
  }
});