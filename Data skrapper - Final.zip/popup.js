/*....
MW:KP
WR:1.0.1
*/
chrome.storage.sync.set({'startApp': 'yes' }, function() {
      //console.log('Settings saved');
});